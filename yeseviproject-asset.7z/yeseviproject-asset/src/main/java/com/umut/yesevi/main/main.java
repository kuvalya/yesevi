package com.umut.yesevi.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.*;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.thrift.TException;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.transport.TIOStreamTransport;
import org.apache.thrift.transport.TTransport;
import org.json.JSONArray;
import org.json.JSONObject;

import com.umut.yesevi.avro.AssetAvro;
import com.umut.yesevi.protobuf.AssetArray;
import com.umut.yesevi.protobuf.AssetPro;
import com.umut.yesevi.thrift.AssetList;
import com.umut.yesevi.thrift.AssetThrift;
import com.umuta.numcompare.thrift.AssetAThrift;

public class main {
	private final static String OUTPUT_PATH = "output/";
	private static File outputFile;

	// number of objects to be tested:
	private final static int BASE_TEST_SIZE = 1_000;
	private static int test_size;

	// Repeating number:
	private final static int REPEATING_NUMBER = 1_000; 

	// test data that will be used for all serialization methods: 
	private static Asset[] assetTestArray;

	// SIZE test variables
	private static long totalFileSize = 0L;
	private static List<Long> serializationSizes;
	//private static String[] serializedFileNames;
	private static List<String> serializedFileNames;

	// TIME test variables:
	private static long startTime = 0L;
	private static long finishTime = 0L;
	private static long totalSerializationTime = 0L;
	private static List<Long> serializationTimes;
	private static long totalDeserializationTime = 0L;
	private static List<Long> deserializationTimes;

	
	// debug sizes for protobuf:
	private static List<Long> debug_protoPreprationTimes;
	private static List<Long> debug_protoFileWriteTimes;
	private static List<Long> debug_protoTotalTimes;
	private static String debug_protoAllTimesString;
	// debug sizes for thrift:
	private static List<Long> debug_thriftPreprationTimes;
	private static List<Long> debug_thriftFileWriteTimes;
	private static List<Long> debug_thriftTotalTimes;
	private static String debug_thriftAllTimesString;
	
	
	public static void main(String[] args) throws IOException, TException {
		Scanner s = new Scanner(System.in);
		System.out.println("Starting tests with only-numbers-set");

		for (int i = 0; i < 3; i++) {
			test_size = (int) (BASE_TEST_SIZE * Math.pow(10, i));

			// Creating test data:
			createAssetTestArray();

			// Wait user for CPU-RAM usage logs:
			System.out.println("\nPress Enter key to start test JSON_test_size_" + test_size);
//			s.nextLine();
			// *-*-*-*-*-* START TO JSON TEST *-*-*-*-*-*-*-*-
			System.out.println("STARTING TO JSON TEST....");
			jsonAssetTest();
			// Print report:
			printReport("ONLY-NUMBERS-SET JSON REPORT");
			System.out.println("END OF JSON TEST.");

			// Wait user to CPU-RAM usage logs:
			System.out.println("\nPress Enter key to start test THRIFT_test_size_" + test_size);
//			s.nextLine();
			// *-*-*-*-*-* START TO THRIFT TEST *-*-*-*-*-*-*-*-
			System.out.println("STARTING THRIFT TEST....");
			thriftAssetTest();
			// Print report:
			printReport("ONLY-NUMBERS-SET THRIFT REPORT");
			System.out.println("END  OF THRIFT TEST.");


			// Wait user to CPU-RAM usage logs:
			System.out.println("\nPress Enter key to start test thriftAssetTest_ALONE_test_size_" + test_size);
//			s.nextLine();
			// *-*-*-*-*-* START TO thriftAssetTest_ALONE TEST *-*-*-*-*-*-*-*-
			System.out.println("STARTING thriftAssetTest_ALONE TEST....");
			thriftAssetTest_ALONE();
			// Print report:
			printReport("ONLY-NUMBERS-SET thriftAssetTest_ALONE REPORT");
			System.out.println("END  OF thriftAssetTest_ALONE TEST.");
						
			
			// Wait user for CPU-RAM usage logs:
			System.out.println("\nPress Enter key to start test PROTOBUF_test_size_" + test_size);
//			s.nextLine();
			// *-*-*-*-*-* START TO PROTOBUF TEST *-*-*-*-*-*-*-*-
			System.out.println("STARTING PROTOBUF TEST....");
			protobufAssetTest();
			// Print report:
			printReport("ONLY-NUMBERS-SET PROTOBUF REPORT");
			System.out.println("END OF PROTOBUF TEST.");

			// Wait user to CPU-RAM usage logs:
			System.out.println("\nPress Enter key to start test AVRO_test_size_" + test_size);
//			s.nextLine();
			// *-*-*-*-*-* START TO AVRO TEST *-*-*-*-*-*-*-*-
			System.out.println("STARTING AVRO TEST....");
			avroAssetTest();
			// Print report:
			printReport("ONLY-NUMBERS-SET AVRO REPORT");
			System.out.println("END OF AVRO TEST.");

			System.out.println("End of test_size " + test_size + " tests. \n\n ");


		}
		System.out.println("End of tests ");
	}

	private static void createAssetTestArray() {
		System.out.println("Creating new test data for " + test_size + " elements...");
		assetTestArray = new Asset[test_size];

		// Creating Asset data:
		for (int i = 0; i < assetTestArray.length; i++) {
			assetTestArray[i] = new Asset((double) 100000000 + i, (float) (0.1 * i), 10 * i, 100 * i);
		}
	}

	private static void resetVariables() throws IOException {
		// Reseting test variables:
		// Deleting old files:
		if (serializedFileNames != null) {
			for (String name : serializedFileNames) {
				new File(name).delete();
			}
		}

		// Reseting SIZE test variables
		totalFileSize = 0L;
		serializationSizes = new ArrayList<Long>();
		//serializedFileNames = new String[REPEATING_NUMBER];
		serializedFileNames = new ArrayList<String>();

		// Reseting TIME test variables:
		startTime = 0L;
		finishTime = 0L;
		totalSerializationTime = 0L;
		serializationTimes = new ArrayList<Long>();
		totalDeserializationTime = 0L;
		deserializationTimes = new ArrayList<Long>();
		
/* !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  */

		// debug sizes for protobuf:
		debug_protoPreprationTimes = new ArrayList<Long>();
		debug_protoFileWriteTimes = new ArrayList<Long>();
		debug_protoTotalTimes = new ArrayList<Long>();
		// debug sizes for thrift:
		debug_thriftPreprationTimes = new ArrayList<Long>();
		debug_thriftFileWriteTimes = new ArrayList<Long>();
		debug_thriftTotalTimes = new ArrayList<Long>();

/* !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  !!! DEBUG !!!  */
		
 
	}

	private static void beforeSerialization(String fileSuffix, int element) {
		// setting output file:
		String fileName = fileSuffix + "Test_" + test_size + "_" + System.currentTimeMillis() + "." + fileSuffix;

		// String path = OUTPUT_PATH + fileSuffix + "/";
		String path = OUTPUT_PATH;

		outputFile = new File(path + fileName);

		// save file names for deserialization:
		//serializedFileNames[element] = path + fileName;
		serializedFileNames.add(path + fileName);

		// Set test variables:
		startTime = System.currentTimeMillis();
	}
	

	private static void afterSerialization(int i) {
		// Do not calculate first 3 processes:
		if(i<2) {
			// Get test variables:
			finishTime = System.currentTimeMillis();

			// set SIZE:
			Long fileSize = outputFile.length();
			serializationSizes.add(fileSize);
			totalFileSize += fileSize;

			// set TIME:
			Long timeForSerialization = finishTime - startTime;
			serializationTimes.add(timeForSerialization);
			totalSerializationTime += timeForSerialization;
		}
	}
	

	private static void beforeDeserialization() {
		// Set test variables:
		startTime = System.currentTimeMillis();
	}
	

	private static void afterDeserialization(int i) {
		// Do not calculate first 3 processes:
		if(i<2) {
			// Get test variables:
			finishTime = System.currentTimeMillis();
	
			// TIME min, max and total:
			Long timeForDeserialization = finishTime - startTime;
			deserializationTimes.add(timeForDeserialization);
			totalDeserializationTime += timeForDeserialization;
		}
	}
	

	private static void printReport(String reportName) {
		System.out.println("***************************** " + reportName + " *******************************");
		System.out.println("number of data:\t" + test_size);
		System.out.println("repeating number:\t" + REPEATING_NUMBER);

		System.out.println("----------------------------------------------------------------------------------");
		System.out.println("DATA\t\t\t" + "AVG\t\t" + "MIN\t\t" + "MAX\t\t" + "NOTES");

		// SIZE avr min max
		long avrSize = totalFileSize / REPEATING_NUMBER;
		System.out.print("Serialization Size" + "\t");
		System.out.print(avrSize / 1024 + "\t\t");
		System.out.print(Collections.min(serializationSizes) / 1024 + "\t\t");
		System.out.print(Collections.max(serializationSizes) / 1024 + "\t\t");
		System.out.print("kb" + "\t\t");
		System.out.println();

		// SERIALIZATION TIME avr min max
		System.out.print("Serialization Time" + "\t");
		System.out.print((double)totalSerializationTime / (double)REPEATING_NUMBER + "\t\t");
		System.out.print(Collections.min(serializationTimes) + "\t\t");
		System.out.print(Collections.max(serializationTimes) + "\t\t");
		System.out.print("ms" + "\t\t");
		System.out.println();

		// DESERIALIZATION TIME avr min max
		System.out.print("Deserialization Time" + "\t");
		System.out.print((double)totalDeserializationTime / (double)REPEATING_NUMBER + "\t\t");
		System.out.print(Collections.min(deserializationTimes) + "\t\t");
		System.out.print(Collections.max(deserializationTimes) + "\t\t");
		System.out.print("ms" + "\t\t");
		System.out.println();

		System.out.println("----------------------------------------------------------------------------------");
	}
		


	private static void jsonAssetTest() throws IOException {
		// reseting test variables:
		resetVariables();

		// Starting JSON serialization:
		System.out.println("Starting Json serialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeSerialization("json", i);

			// Start serialization:
			jsonAssetSerialization(assetTestArray, outputFile);

			// Get test variables:
			afterSerialization(i);
		}

		// Starting JSON deserialization:
		System.out.println("Starting Json deserialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeDeserialization();

			// Start deserialization:
			jsonAssetDeserialization(new File(serializedFileNames.get(i)));

			// Get test variables:
			afterDeserialization(i);
		}
	}

	private static void jsonAssetSerialization(Asset[] testArray, File outputFile) throws IOException {
		// create a json array:
		JSONArray jsonArr = new JSONArray();

		// create a json object:
		JSONObject jsonObj = new JSONObject();

		// save objects into array:
		for (int i = 0; i < test_size; i++) {
			jsonObj = new JSONObject();
			jsonObj.put("id", testArray[i].getId());
			jsonObj.put("rationum", testArray[i].getRationum());
			jsonObj.put("barcode", testArray[i].getBarcode());
			jsonObj.put("itemnum", testArray[i].getItemnum());
			jsonArr.put(jsonObj);
		}

		FileOutputStream jsonOutputStream = new FileOutputStream(outputFile);
		jsonOutputStream.write(jsonArr.toString().getBytes());
		jsonOutputStream.close();
	}

	private static JSONArray jsonAssetDeserialization(File dataFile) throws IOException {
		String jsonData = new String(Files.readAllBytes(dataFile.toPath()));
		JSONArray jsonArr = new JSONArray(jsonData);

		return jsonArr;
	}
	
/* DEBUG for thrift alone test */

	

	private static void thriftAssetTest_ALONE() throws IOException, TException {
		// reseting test variables:
		resetVariables();

		// Starting Thrift serialization:
		System.out.println("Starting Thrift ALONE serialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeSerialization("thrift_ALONE", i);

			// Start serialization:
			thriftAsset_ALONE_Serialization(assetTestArray, outputFile);

			// Get test variables:
			afterSerialization(i);
		}

		// Starting Thrift deserialization:
		System.out.println("Starting Thrift_ALONE deserialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeDeserialization();

			// Start deserialization:
			thriftAsset_ALONE_Deserialization(new File(serializedFileNames.get(i)));

			// Get test variables:
			afterDeserialization(i);
		}
	}


    // Thrift nesnesini dosyaya yazma
    public static void thriftAsset_ALONE_Serialization(Asset[] testArray, File outputFile) throws TException, IOException {

        try (FileOutputStream fos = new FileOutputStream(outputFile);
             TTransport transport = new TIOStreamTransport(fos)) {
             TCompactProtocol protocol = new TCompactProtocol(transport);
        	for(Asset asset:testArray) {
        		AssetAThrift assetAT = new AssetAThrift(asset.getId(), asset.getRationum(), asset.getBarcode(), asset.getItemnum());
        		assetAT.write(protocol);  // Her nesneyi sırayla yaz
        	}
        }
    }
    

    // çozumleme....
    public static List<Asset> thriftAsset_ALONE_Deserialization(File fullFileName) throws TException, IOException {
        List<Asset> assets = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(fullFileName);
             TTransport transport = new TIOStreamTransport(fis)) {
            TCompactProtocol protocol = new TCompactProtocol(transport);
            transport.open();

            while (fis.available() > 0) {
                AssetAThrift assetAT = new AssetAThrift();
                assetAT.read(protocol);

                Asset asset = new Asset(assetAT.getId(), (float)assetAT.getRationum(), assetAT.getBarcode(), assetAT.getItemnum());
                assets.add(asset);
            }
        }
        return assets;
    }

	

    public static AssetList thriftAssetDeserializationX(File dataFile) throws TException, IOException {
        AssetList thriftList = new AssetList();
        try (FileInputStream fis = new FileInputStream(dataFile);
             TTransport transport = new TIOStreamTransport(fis)) {
        	TCompactProtocol protocol = new TCompactProtocol(transport);
            thriftList.read(protocol);
        }
        return thriftList;
    }
	
	
	
	
	
/* DEBUG for thrift alone test 	 */
	
	

	private static void thriftAssetTest() throws IOException, TException {
		// reseting test variables:
		resetVariables();

		// Starting Thrift serialization:
		System.out.println("Starting Thrift serialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeSerialization("thrift", i);

			// Start serialization:
			thriftAssetSerialization(assetTestArray, outputFile);

			// Get test variables:
			afterSerialization(i);
		}

/* !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! */

			System.out.println("*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-**--*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*");
			System.out.println("debug report thrift...");
			System.out.println("thrift prep average: " + debug_thriftPreprationTimes.stream().mapToDouble(val -> val).average());
			System.out.println("thrift file average: " + debug_thriftFileWriteTimes.stream().mapToDouble(val -> val).average());
			System.out.println("thrift total average: " + debug_thriftTotalTimes.stream().mapToDouble(val -> val).average());

			System.out.println("debug print lists...");
			System.out.println("debug_thriftPreprationTimes:" + debug_thriftPreprationTimes);
			System.out.println("debug_thriftFileWriteTimes:" + debug_thriftFileWriteTimes);
			System.out.println("debug_thriftTotalTimes:" + debug_thriftTotalTimes);

			System.out.println("*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-**--*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*");

/* !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! */
			
		// Starting Thrift deserialization:
		System.out.println("Starting Thrift deserialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeDeserialization();

			// Start deserialization:
			thriftAssetDeserialization(new File(serializedFileNames.get(i)));

			// Get test variables:
			afterDeserialization(i);
		}
	}

	
    public static void thriftAssetSerialization(Asset[] testArray, File outputFile) throws TException, IOException {
		// Creating thrift data array:
    	AssetList thriftAssetList = new AssetList();
		int len = testArray.length;
		long serStart = System.currentTimeMillis();
		for (int i = 0; i < len; i++) {
            AssetThrift asset = new AssetThrift();
            asset.setId(testArray[i].getId());  
            asset.setRationum(testArray[i].getRationum());
            asset.setBarcode(testArray[i].getBarcode());
            asset.setItemnum(testArray[i].getItemnum());
            thriftAssetList.addToAssets(asset);		
		}
		long serEnd = System.currentTimeMillis();
		debug_thriftPreprationTimes.add(serEnd-serStart);
		
		// Serializing to disk.
		long desStart = System.currentTimeMillis();
        try (FileOutputStream fos = new FileOutputStream(outputFile);
                TTransport transport = new TIOStreamTransport(fos)) {
               //TBinaryProtocol protocol = new TBinaryProtocol(transport);
        		TCompactProtocol protocol = new TCompactProtocol(transport);
               thriftAssetList.write(protocol);  
           }
		long desEnd = System.currentTimeMillis();
		debug_thriftFileWriteTimes.add(desEnd-desStart);
		
		debug_thriftTotalTimes.add(desEnd-serStart);
        
    }

    public static AssetList thriftAssetDeserialization(File dataFile) throws TException, IOException {
        AssetList thriftList = new AssetList();
        try (FileInputStream fis = new FileInputStream(dataFile);
             TTransport transport = new TIOStreamTransport(fis)) {
        	TCompactProtocol protocol = new TCompactProtocol(transport);
            thriftList.read(protocol);
        }
        return thriftList;
    }
	
	
	private static void protobufAssetTest() throws IOException {
		// reseting test variables:
		resetVariables();

		// Starting Protobuf serialization:
		System.out.println("Starting Protobuf serialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeSerialization("protobuf", i);

			// Start serialization:
			protobufAssetSerialization(assetTestArray, outputFile);

			// Get test variables:
			afterSerialization(i);
		}

/* !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! */

			System.out.println("*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-**--*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*");
			System.out.println("debug report proto...");
			System.out.println("proto prep average: " + debug_protoPreprationTimes.stream().mapToDouble(val -> val).average());
			System.out.println("proto file average: " + debug_protoFileWriteTimes.stream().mapToDouble(val -> val).average());
			System.out.println("proto total average: " + debug_protoTotalTimes.stream().mapToDouble(val -> val).average());

			System.out.println("debug lists proto...");
			System.out.println("debug_protoPreprationTimes:" + debug_protoPreprationTimes);
			System.out.println("debug_protoFileWriteTimes:" + debug_protoFileWriteTimes);
			System.out.println("debug_protoTotalTimes:" + debug_protoTotalTimes);

			System.out.println("*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-**--*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*");

/* !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! !!! DEBUG !!! */

		// Starting Protobuf deserialization:
		System.out.println("Starting Protobuf deserialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeDeserialization();

			// Start deserialization:
			protobufAssetDeserialization(new File(serializedFileNames.get(i)));

			// Get test variables:
			afterDeserialization(i);
		}
	}

	private static void protobufAssetSerialization(Asset[] testArray, File outputFile) throws IOException {
		// Protobuf builders:
		AssetPro.Builder proBuilder = AssetPro.newBuilder();
		AssetArray.Builder proArrayBuilder = AssetArray.newBuilder();

		// Creating protobuf data array:
		int len = testArray.length;
		long serStart = System.currentTimeMillis();
		for (int i = 0; i < len; i++) {
			proArrayBuilder.addAsset(proBuilder.setId(testArray[i].getId())
									.setRationum(testArray[i].getRationum())
									.setBarcode(testArray[i].getBarcode())
									.setItemnum(testArray[i].getItemnum())
									.build());
		}
		long serEnd= System.currentTimeMillis();
		debug_protoPreprationTimes.add(serEnd-serStart);

		// Serializing to disk.
		long desStart = System.currentTimeMillis();
		FileOutputStream output = new FileOutputStream(outputFile);
		proArrayBuilder.build().writeTo(output);
		output.close();
		long desEnd = System.currentTimeMillis();
		debug_protoFileWriteTimes.add(desEnd-desStart);
		debug_protoTotalTimes.add(desEnd-serStart);
	}

	private static AssetArray protobufAssetDeserialization(File dataFile) throws IOException {
		AssetArray proArray = AssetArray.parseFrom(new FileInputStream(dataFile.getPath()));
		return proArray;
	}

	private static void avroAssetTest() throws IOException {
		// reseting test variables:
		resetVariables();

		// create AVRO schema:
		Schema avroSchema = new Schema.Parser().parse(new File("avro/asset.avsc"));

		// Starting Avro serialization:
		System.out.println("Starting Avro serialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeSerialization("avro", i);

			// Start serialization:
			avroAssetSerialization(avroSchema, assetTestArray, outputFile);

			// Get test variables:
			afterSerialization(i);
		}

		// Starting Avro deserialization:
		System.out.println("Starting Avro deserialization....");
		for (int i = 0; i < REPEATING_NUMBER+3; i++) {	// Do not calculate first 3 progress
			// Set test variables:
			beforeDeserialization();

			// Start deserialization:
			avroAssetDeserialization(avroSchema, new File(serializedFileNames.get(i)));

			// Get test variables:
			afterDeserialization(i);
		}
	}

	private static void avroAssetSerialization(Schema schema, Asset[] testArray, File outputFile) throws IOException {
		DatumWriter<GenericRecord> datumWriter = new GenericDatumWriter<GenericRecord>(schema);
		DataFileWriter<GenericRecord> dataFileWriter = new DataFileWriter<GenericRecord>(datumWriter);
		dataFileWriter.create(schema, outputFile);

		// create AVRO records:
		int arrayLength = testArray.length;
		for (int i = 0; i < arrayLength; i++) {
			GenericRecord avroRecord = new GenericData.Record(schema);
			avroRecord.put("id", testArray[i].getId());
			avroRecord.put("rationum", testArray[i].getRationum());
			avroRecord.put("barcode", testArray[i].getBarcode());
			avroRecord.put("itemnum", testArray[i].getItemnum());
			dataFileWriter.append(avroRecord);
		}
		dataFileWriter.close();
	}

	private static AssetAvro[] avroAssetDeserialization(Schema schema, File dataFile) throws IOException {
		AssetAvro[] avroArray = new AssetAvro[test_size];

		DatumReader<AssetAvro> datumReader = new SpecificDatumReader<AssetAvro>(AssetAvro.class);
		DataFileReader<AssetAvro> dataFileReader = new DataFileReader<AssetAvro>(dataFile, datumReader);

		int i = 0;
		while (dataFileReader.hasNext()) {
			avroArray[i++] = dataFileReader.next();
		}
		dataFileReader.close();

		return avroArray;
	}

}
